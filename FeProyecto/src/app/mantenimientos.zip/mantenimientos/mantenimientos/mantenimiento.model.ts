export interface Mantenimiento{
  id:string;
  descripcion:string;
  estado:string;
  corregido:boolean;
  observaciones:string;
  imagenes: string[];
  fecha?: Date;
  item_id:string;
  ubicacion_id:string;
}
