import { Component } from '@angular/core';

@Component({
  selector: 'app-registrar-mantenimiento',
  templateUrl: './registrar-mantenimiento.component.html',
  styleUrls: ['./registrar-mantenimiento.component.css']
})
export class RegistrarMantenimientoComponent {

}
